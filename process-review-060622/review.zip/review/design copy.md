input - a string containing Green,Amber,Red
* if not string, return error

eg "Green"


output - return a string, Green: n, Amber: n, Red: n, Uncounted: n