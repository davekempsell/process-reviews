work for a school reports company, helping teachers see how their students have done on tests

get a string of comma separated values test results from schools

build simple report

output - string saying each grade and how many times it appears

input = eg. "Green, Green, Amber, Red, Green"

output eg. "Green: 3\nAmber: 1\nRed: 1"

not green/amber/red = "Green,Dave,Whimsy,Red"
"Green: 1\nAmber:0\nRed: 1\nUncounted: 2"

empty/not a string = error: invalid input